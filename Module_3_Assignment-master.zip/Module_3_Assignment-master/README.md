Coursera course: HTML, CSS, and Javascript for Web Developers, Module 3 Coding Assignment, completed.

link: https://zohebh02.github.io/Module_3_Assignment/

